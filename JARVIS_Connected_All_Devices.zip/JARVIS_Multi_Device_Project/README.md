# J.A.R.V.I.S — Advanced Python Assistant

A local Flask + Gemini assistant with a cinematic blue sci-fi dashboard, chat, voice controls, SQLite conversation history and saved notes, safe browser/app shortcuts, and prompt-to-OpenSCAD model generation.

## Features
- Gemini chat (API key stays in local `.env`, not in browser code).
- Chat history stored locally in `jarvis_memory.db`; clear it from the UI.
- Saved memory notes that can be reviewed and deleted.
- Browser speech recognition and speech synthesis where supported (usually Chrome/Edge).
- Optional wake phrase listening mode. This is browser speech recognition, not a guaranteed always-on background service; keep the page open and microphone permission enabled.
- 3D model generation as editable `.scad` files, downloaded from the dashboard. Install OpenSCAD separately to preview/render them.
- Explicit, allowlisted actions to open a few approved sites and simple apps. No arbitrary shell command execution.

## Setup (Windows)
1. Install Python 3.10+.
2. Extract this ZIP into a normal folder.
3. Double-click `run_windows.bat`.
4. On first run, open the created `.env` file in Notepad and set `GEMINI_API_KEY=your_real_key`. Save it.
5. Stop the server with Ctrl+C in the terminal, then double-click `run_windows.bat` again.
6. Open `http://127.0.0.1:5000`.

## Setup (macOS/Linux)
Run `chmod +x run_mac_linux.sh`, then `./run_mac_linux.sh`. Add the API key to `.env` and restart if necessary.

## Voice
Use the mic button and allow browser microphone access. Turn on “Wake word” in Settings and say “Hey Jarvis” while the page is open. Browser and OS support varies. Do not use voice activation in places where recording is not appropriate.

## 3D models
Open “Create 3D Model”, describe a harmless object, and download the generated `.scad` file. Open it with OpenSCAD to inspect and render it. Generated geometry is a starting point; inspect dimensions before fabrication.

## Privacy and safety
This app runs on your computer and stores chats/notes in a local SQLite file. Delete chats/notes using the interface. Keep `.env` private and never share your API key. The desktop controls only allow listed actions; they do not execute arbitrary commands. Do not expose the Flask server to the public internet.

## Troubleshooting
- **Gemini not configured:** add a valid key to `.env`, then restart.
- **Quota or API errors:** verify the key, model access, internet, and your provider's quota.
- **Mic unavailable:** use a supported browser and grant microphone permission; typed chat still works.
- **Port in use:** change `PORT=5001` in `.env`, then open `http://127.0.0.1:5001`.


## Device controls (permission-limited)
- **Apps:** launches only a small OS-specific allowlist. No arbitrary command execution.
- **Files:** reads/creates/edits/deletes common text files only inside `JARVIS_WORKSPACE` (default `./workspace`). File saves and deletes prompt for confirmation; folder deletion is disabled. Path traversal and symlinks are rejected.
- **Browser:** opens a fixed list of approved websites.
- **System:** reads basic CPU/RAM/disk/platform details; it does not read passwords or browser credentials. Some metrics require `psutil`.
- **Voice:** browser mic input, speech output, and optional wake phrase. The page must remain open; browser support varies.
- **Important actions:** saving and deleting files ask for confirmation in the interface. Do not expose this app to the public internet.


## Installed-app launcher
The System Control page scans standard application menus (Windows Start Menu shortcuts, macOS Applications folders, and Linux desktop entries) and displays a searchable list. Each launch requires confirmation. Discovery varies by operating system; portable apps and some Microsoft Store apps may not appear. This is an app launcher, not automatic deep integration with every app's private data or account. For that, each service needs an official API/connector and separate authorization.


## Multi-AI + Google research
JARVIS can query every provider for which you configure an API key, then combine the available answers:
- Gemini (`GEMINI_API_KEY`, default primary/synthesis model)
- OpenAI (`OPENAI_API_KEY`)
- Anthropic Claude (`ANTHROPIC_API_KEY`)
- Perplexity (`PERPLEXITY_API_KEY`)
- Google web search (`GOOGLE_SEARCH_API_KEY` and `GOOGLE_SEARCH_CX`)

**Important:** There is no universal key that connects every AI. Each provider needs its own account/API key, some APIs may require billing, and provider names/models/endpoints can change. Google Search uses the official Programmable Search API and requires both a key and search-engine ID. If not configured, JARVIS clearly notes that it did not get Google results. Requests are sent to whichever providers you enable; review their privacy and billing policies first. Do not paste API keys into chat; keep them in your local `.env` file. Never publish this local server to the public internet.
