# JARVIS Multi-Device Python Project

This adds a **multi-device scaffold** to the existing JARVIS assistant: Windows and macOS desktop agents, a mobile website/PWA, an Android Studio companion-app starter, one-time device pairing, a shared message stream, and a two-stage approval queue for device actions.

## Important status
This is a working **starter architecture**, not a finished commercial remote-control product. The existing assistant remains in `app.py`; the pairing service runs separately as `multi_device_server.py`. The Android app is source code, not a prebuilt APK. No real devices or external AI keys were tested in this environment.

## 1. Install and configure
- Python 3.10+.
- From this folder: `python -m pip install -r requirements.txt`
- Copy `.env.example` to `.env` and set `GEMINI_API_KEY` if you want the existing AI chat, plus a long random `JARVIS_ADMIN_TOKEN` for device administration.
- Start the existing assistant using `run_windows.bat` or `run_mac_linux.sh`.
- In a second terminal run `python multi_device_server.py`.
- Device service defaults to `127.0.0.1:5055`, so it is local-only. For devices on different networks, deploy behind HTTPS or use a private VPN and bind only to the private interface. Do not port-forward this Flask development server to the public internet.

## 2. Pair a desktop
1. Request a one-time code using the admin token:
   `curl -X POST http://127.0.0.1:5055/api/admin/pair-code -H "Authorization: Bearer YOUR_ADMIN_TOKEN"`
2. On the device to pair, run:
   `python agents/pair_device.py --server http://127.0.0.1:5055 --code CODE_FROM_STEP_1 --name "My Windows PC" --platform windows`
   Use `--platform macos` for a Mac. For a remote service, use its HTTPS URL.
3. Store the returned `device_id` and `device_token` securely in environment variables `JARVIS_DEVICE_ID` and `JARVIS_DEVICE_TOKEN`. The server stores only the token hash; the token is returned once.
4. Start the agent. Windows: `agents\\run_windows_agent.bat`; macOS: export the environment variables and `python3 agents/device_agent.py --server "$JARVIS_SERVER_URL"` (or use the `.command` helper).

Pairing codes expire after five minutes and are single-use. If a token is lost, revoke the paired device in a future admin UI / delete that device row from `devices.sqlite3` and pair again. Protect the SQLite file.

## 3. Android — both methods
- **Mobile website:** open the HTTPS URL in Android Chrome. Use “Add to Home screen” if offered. The responsive portal is under `/` on port 5055.
- **Dedicated app:** open `android-app/` in Android Studio, replace the placeholder HTTPS host, sync Gradle, then build and install. This source starter embeds the mobile portal in a native app shell; it is not yet an independent native UI or APK.

## 4. Approvals and allowed actions
Admin endpoints require `Authorization: Bearer <JARVIS_ADMIN_TOKEN>`. Create a proposed action at `/api/admin/actions`, inspect it at `/api/admin/actions`, then explicitly approve it at `/api/admin/actions/<id>/approve` or reject it at `/api/admin/actions/<id>/reject`. The agent receives only approved actions. The agent supports only `get_system_info`, `open_url`, and `notify`; opening a URL also asks for local confirmation in the agent terminal. Arbitrary shell commands, arbitrary file access, keystroke injection, and background surveillance are not implemented.

## 5. Shared assistant access
The existing Flask AI app is at port 5000; all desktop/mobile users can use that shared server URL after secure deployment. The device service also includes a small authenticated shared-message endpoint (`/api/shared/messages`) for device-authenticated clients. This is not yet a full synchronized AI conversation UI across every client; that requires linking the two services and adding per-user/device authorization.

## Security notes
- Use HTTPS or a private VPN for any remote access. Local HTTP is allowed only for localhost testing by the desktop agent.
- Do not commit `.env`, API keys, device tokens, or database files.
- Keep the admin token long and private. This scaffold has no user accounts, MFA, device revocation UI, rate limiting, production WSGI server, or TLS termination built in; add these before real remote use.
- macOS and Windows permissions still apply. Android limits background operations and app control; this project does not bypass OS security or silently control every app.
