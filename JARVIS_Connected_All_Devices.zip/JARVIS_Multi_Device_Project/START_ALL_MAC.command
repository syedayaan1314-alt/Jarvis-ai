#!/bin/bash
set -e
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then python3 -m venv .venv; fi
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
echo "Edit .env and set a long random JARVIS_ADMIN_TOKEN before pairing devices."
( python app.py ) &
APP_PID=$!
( python multi_device_server.py ) &
DEVICE_PID=$!
trap 'kill "$APP_PID" "$DEVICE_PID" 2>/dev/null || true' EXIT
sleep 3
open http://127.0.0.1:5000 || true
open http://127.0.0.1:5055 || true
wait
