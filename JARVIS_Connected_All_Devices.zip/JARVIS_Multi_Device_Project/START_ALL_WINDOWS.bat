@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3 -m venv .venv || python -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo JARVIS setup complete. Edit .env and set a long random JARVIS_ADMIN_TOKEN.
echo This launcher starts the assistant and device service in separate windows.
start "JARVIS Assistant" cmd /k "cd /d %~dp0 && .venv\Scripts\python.exe app.py"
start "JARVIS Device Service" cmd /k "cd /d %~dp0 && .venv\Scripts\python.exe multi_device_server.py"
timeout /t 3 >nul
start "" http://127.0.0.1:5000
start "" http://127.0.0.1:5055
endlocal
