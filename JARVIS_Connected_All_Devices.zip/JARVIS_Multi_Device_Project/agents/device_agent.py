"""Cross-platform JARVIS desktop agent. Only runs a tiny explicit action allowlist."""
import argparse, json, os, platform, time, urllib.request, urllib.error, webbrowser, socket, shutil
from pathlib import Path

def request(url, did, token, method='GET', data=None):
 raw=None if data is None else json.dumps(data).encode()
 req=urllib.request.Request(url, data=raw, method=method, headers={'Content-Type':'application/json','X-Jarvis-Device':did,'X-Jarvis-Token':token})
 with urllib.request.urlopen(req, timeout=15) as r: return json.loads(r.read().decode())

def execute(task):
 action,args=task.get('action'),task.get('args') or {}
 if action=='get_system_info':
  return json.dumps({'platform':platform.platform(),'python':platform.python_version(),'hostname':socket.gethostname(),'cpu_count':os.cpu_count(),'home_free_bytes':shutil.disk_usage(str(Path.home())).free})
 if action=='open_url':
  url=str(args.get('url',''))
  if not (url.startswith('https://') or url.startswith('http://')): return 'Rejected: only http/https URLs are allowed.'
  # Opening a browser is consequential enough to ask at the local console too.
  answer=input(f'JARVIS requests opening {url}. Approve locally? [y/N] ').strip().lower()
  if answer!='y': return 'Declined on device.'
  webbrowser.open(url); return 'Browser open request sent.'
 if action=='notify':
  msg=str(args.get('message','JARVIS notification'))[:250]
  print('\n[JARVIS NOTIFICATION]',msg)
  return 'Notification printed in this agent console.'
 return 'Rejected: unsupported action.'

def main():
 p=argparse.ArgumentParser(); p.add_argument('--server',required=True,help='Base URL of private JARVIS service'); p.add_argument('--device-id',default=os.getenv('JARVIS_DEVICE_ID','')); p.add_argument('--token',default=os.getenv('JARVIS_DEVICE_TOKEN','')); p.add_argument('--interval',type=int,default=5); a=p.parse_args()
 base=a.server.rstrip('/')
 if not base.startswith('https://') and not (base.startswith('http://127.0.0.1') or base.startswith('http://localhost')):
  raise SystemExit('Refusing non-HTTPS remote server. Use HTTPS, or localhost for local testing.')
 if not a.device_id or not a.token: raise SystemExit('Pair first, then provide device ID and token (prefer environment variables).')
 print('JARVIS agent started. Ctrl+C stops it. Only approved allowlisted tasks are accepted.')
 while True:
  try:
   tasks=request(base+'/api/device/tasks',a.device_id,a.token).get('tasks',[])
   for task in tasks:
    try: result=execute(task)
    except Exception as e: result='Action failed: '+str(e)[:200]
    request(base+'/api/device/result',a.device_id,a.token,'POST',{'action_id':task['id'],'result':result})
  except urllib.error.HTTPError as e:
   print('Server error:',e.code,e.read().decode()[:200])
   if e.code==401: raise SystemExit('Device token invalid/revoked. Pair again.')
  except Exception as e: print('Connection issue:',str(e)[:180])
  time.sleep(max(3,a.interval))
if __name__=='__main__': main()
