import argparse,json,urllib.request
p=argparse.ArgumentParser(); p.add_argument('--server',required=True); p.add_argument('--code',required=True); p.add_argument('--name',required=True); p.add_argument('--platform',default='desktop'); a=p.parse_args()
req=urllib.request.Request(a.server.rstrip('/')+'/api/pair',data=json.dumps({'code':a.code,'name':a.name,'platform':a.platform}).encode(),headers={'Content-Type':'application/json'},method='POST')
with urllib.request.urlopen(req,timeout=15) as r: result=json.loads(r.read().decode())
print(json.dumps(result,indent=2)); print('\nIMPORTANT: copy device_id and device_token into a secure password manager or environment variables. The token is only displayed once.')
