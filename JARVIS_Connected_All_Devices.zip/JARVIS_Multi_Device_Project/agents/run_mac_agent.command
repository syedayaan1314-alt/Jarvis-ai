#!/bin/bash
cd "$(dirname "$0")/.."
python3 agents/device_agent.py --server "$JARVIS_SERVER_URL" --device-id "$JARVIS_DEVICE_ID" --token "$JARVIS_DEVICE_TOKEN"
