@echo off
cd /d "%~dp0.."
if "%JARVIS_DEVICE_ID%"=="" echo Set JARVIS_DEVICE_ID and JARVIS_DEVICE_TOKEN environment variables first.
python agents\device_agent.py --server "%JARVIS_SERVER_URL%" --device-id "%JARVIS_DEVICE_ID%" --token "%JARVIS_DEVICE_TOKEN%"
pause
