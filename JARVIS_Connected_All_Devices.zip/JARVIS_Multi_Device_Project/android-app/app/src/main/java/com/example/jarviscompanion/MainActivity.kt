package com.example.jarviscompanion

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.widget.EditText
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.ViewGroup
import android.graphics.Color

class MainActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
    val saved = prefs.getString("server_url", "https://YOUR_PRIVATE_JARVIS_HOST") ?: "https://YOUR_PRIVATE_JARVIS_HOST"
    val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 12); setBackgroundColor(Color.rgb(8,11,24)) }
    val title = TextView(this).apply { text = "J.A.R.V.I.S  •  Companion"; textSize = 22f; setTextColor(Color.WHITE) }
    val url = EditText(this).apply { setText(saved); hint = "https://your-private-jarvis-host"; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
    val open = Button(this).apply { text = "Connect securely" }
    val note = TextView(this).apply { text = "Use HTTPS or a private VPN. Do not enter API keys here. Pairing is handled by the companion portal."; setTextColor(Color.LTGRAY) }
    val web = WebView(this).apply { webViewClient = WebViewClient(); webChromeClient = WebChromeClient(); settings.javaScriptEnabled = true; settings.domStorageEnabled = true }
    root.addView(title); root.addView(url); root.addView(open); root.addView(note)
    root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)); setContentView(root)
    open.setOnClickListener {
      val address = url.text.toString().trim()
      if (address.startsWith("https://")) { prefs.edit().putString("server_url", address).apply(); web.loadUrl(address) }
      else { url.error = "HTTPS URL required" }
    }
    if (saved.startsWith("https://") && !saved.contains("YOUR_PRIVATE_JARVIS_HOST")) web.loadUrl(saved)
  }
  override fun onBackPressed() { setContentView(android.webkit.WebView(this).apply { webViewClient = WebViewClient(); loadUrl("about:blank") }) }
}
