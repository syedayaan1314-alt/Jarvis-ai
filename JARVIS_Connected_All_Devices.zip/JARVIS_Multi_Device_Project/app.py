import os, re, json, sqlite3, platform, subprocess, webbrowser, shutil, requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
from flask import Flask, render_template, request, jsonify, send_from_directory
from dotenv import load_dotenv

try:
    from google import genai
except Exception:
    genai = None

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
app = Flask(__name__)
DB_PATH = BASE_DIR / "jarvis_memory.db"
MODEL_DIR = BASE_DIR / "models"
MODEL_DIR.mkdir(exist_ok=True)
WORKSPACE = Path(os.getenv("JARVIS_WORKSPACE", str(BASE_DIR / "workspace"))).expanduser().resolve()
WORKSPACE.mkdir(parents=True, exist_ok=True)
MAX_FILE_BYTES = 200_000
ALLOWED_EXTENSIONS = {".txt", ".md", ".json", ".csv", ".py", ".html", ".css", ".js", ".scad"}
MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
client = genai.Client(api_key=API_KEY) if genai and API_KEY else None
GOOGLE_SEARCH_KEY = os.getenv("GOOGLE_SEARCH_API_KEY", "").strip()
GOOGLE_SEARCH_CX = os.getenv("GOOGLE_SEARCH_CX", "").strip()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
PERPLEXITY_API_KEY = os.getenv("PERPLEXITY_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-3-5-haiku-latest")
PERPLEXITY_MODEL = os.getenv("PERPLEXITY_MODEL", "sonar")

SYSTEM_PROMPT = """You are JARVIS, a helpful, concise personal AI assistant. Address the user politely as Sir when natural.
Never claim you performed computer actions unless a tool result confirms it. For desktop actions, direct the user to the explicit controls.
When asked to make a 3D model, create a safe, editable OpenSCAD script. Do not include dangerous or weapon-related designs.
"""

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL,
        content TEXT NOT NULL, created_at TEXT NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS memories (
        id INTEGER PRIMARY KEY AUTOINCREMENT, note TEXT NOT NULL,
        created_at TEXT NOT NULL)""")
    return con

def save_message(role, content):
    with db() as con:
        con.execute("INSERT INTO messages(role,content,created_at) VALUES(?,?,?)",
                    (role, content, datetime.now().isoformat(timespec="seconds")))

def safe_filename(name):
    name = re.sub(r'[^a-zA-Z0-9_-]+', '_', name).strip('_')[:48]
    return name or "jarvis_model"

@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/history")
def history():
    with db() as con:
        rows = con.execute("SELECT role,content,created_at FROM messages ORDER BY id DESC LIMIT 60").fetchall()
    return jsonify({"messages": [dict(r) for r in reversed(rows)]})

@app.delete("/api/history")
def clear_history():
    with db() as con:
        con.execute("DELETE FROM messages")
    return jsonify({"ok": True})

@app.get("/api/memories")
def get_memories():
    with db() as con:
        rows = con.execute("SELECT id,note,created_at FROM memories ORDER BY id DESC").fetchall()
    return jsonify({"memories": [dict(r) for r in rows]})

@app.post("/api/memories")
def add_memory():
    note = (request.json or {}).get("note", "").strip()
    if not note or len(note) > 500:
        return jsonify({"error": "Enter a note up to 500 characters."}), 400
    with db() as con:
        cur = con.execute("INSERT INTO memories(note,created_at) VALUES(?,?)",
                          (note, datetime.now().isoformat(timespec="seconds")))
        item_id = cur.lastrowid
    return jsonify({"ok": True, "id": item_id, "note": note})

@app.delete("/api/memories/<int:item_id>")
def delete_memory(item_id):
    with db() as con:
        con.execute("DELETE FROM memories WHERE id=?", (item_id,))
    return jsonify({"ok": True})

def google_search(query, limit=5):
    """Google Programmable Search API. Requires both key and search-engine ID."""
    if not GOOGLE_SEARCH_KEY or not GOOGLE_SEARCH_CX:
        return [], "Google Search API not configured"
    try:
        r = requests.get("https://www.googleapis.com/customsearch/v1",
            params={"key": GOOGLE_SEARCH_KEY, "cx": GOOGLE_SEARCH_CX, "q": query, "num": min(limit, 10)},
            timeout=12)
        r.raise_for_status()
        items = r.json().get("items", [])
        results = [{"title": x.get("title",""), "url": x.get("link",""), "snippet": x.get("snippet","")}
                   for x in items if x.get("link","").startswith("http")]
        return results, None
    except Exception as exc:
        return [], f"Google search failed: {str(exc)[:120]}"

def call_openai(prompt):
    if not OPENAI_API_KEY: return None
    r = requests.post("https://api.openai.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type":"application/json"},
        json={"model": OPENAI_MODEL, "messages":[{"role":"system","content":SYSTEM_PROMPT},
              {"role":"user","content":prompt}], "max_tokens":900}, timeout=35)
    r.raise_for_status()
    return (r.json()["choices"][0]["message"]["content"] or "").strip()

def call_anthropic(prompt):
    if not ANTHROPIC_API_KEY: return None
    r = requests.post("https://api.anthropic.com/v1/messages",
        headers={"x-api-key":ANTHROPIC_API_KEY, "anthropic-version":"2023-06-01",
                 "content-type":"application/json"},
        json={"model":ANTHROPIC_MODEL,"max_tokens":900,
              "system":SYSTEM_PROMPT,"messages":[{"role":"user","content":prompt}]}, timeout=35)
    r.raise_for_status()
    return "".join(x.get("text","") for x in r.json().get("content",[]) if x.get("type")=="text").strip()

def call_perplexity(prompt):
    if not PERPLEXITY_API_KEY: return None
    r = requests.post("https://api.perplexity.ai/chat/completions",
        headers={"Authorization":f"Bearer {PERPLEXITY_API_KEY}","Content-Type":"application/json"},
        json={"model":PERPLEXITY_MODEL,"messages":[{"role":"system","content":SYSTEM_PROMPT},
              {"role":"user","content":prompt}],"max_tokens":900}, timeout=40)
    r.raise_for_status()
    return (r.json()["choices"][0]["message"]["content"] or "").strip()

def research_question(message):
    """Search Google when configured and query every configured AI provider in parallel."""
    search_results, search_error = google_search(message)
    sources = "\n".join(f"- {x['title']}: {x['snippet']} (URL: {x['url']})" for x in search_results)
    provider_prompt = (f"User question: {message}\n\nGoogle web search results (may be empty):\n"
                       f"{sources or '(No Google results available; do not pretend to have searched.)'}\n\n"
                       "Answer clearly. Use the search results when relevant, distinguish facts from uncertainty, "
                       "and include source URLs when available. Do not invent citations.")
    providers = {}
    calls = {}
    if client:
        calls["Gemini"] = lambda: (getattr(client.models.generate_content(
            model=MODEL_NAME, contents=SYSTEM_PROMPT + "\n\n" + provider_prompt), "text", None) or "").strip()
    if OPENAI_API_KEY: calls["OpenAI"] = lambda: call_openai(provider_prompt)
    if ANTHROPIC_API_KEY: calls["Anthropic Claude"] = lambda: call_anthropic(provider_prompt)
    if PERPLEXITY_API_KEY: calls["Perplexity"] = lambda: call_perplexity(provider_prompt)
    with ThreadPoolExecutor(max_workers=max(1, len(calls))) as pool:
        futures = {pool.submit(fn): name for name, fn in calls.items()}
        for future in as_completed(futures):
            name = futures[future]
            try:
                answer = future.result()
                if answer: providers[name] = answer[:7000]
            except Exception as exc:
                providers[name] = f"(Provider unavailable: {str(exc)[:160]})"
    return search_results, search_error, providers

@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    if not message:
        return jsonify({"error": "Please type a message."}), 400
    if len(message) > 8000:
        return jsonify({"error": "Message is too long (8,000 character limit)."}), 400
    save_message("user", message)
    try:
        with db() as con:
            mems = con.execute("SELECT note FROM memories ORDER BY id DESC LIMIT 12").fetchall()
            recent = con.execute("SELECT role,content FROM messages ORDER BY id DESC LIMIT 12").fetchall()
        memory_context = "\n".join(f"- {m['note']}" for m in mems)
        history_text = "\n".join(f"{r['role']}: {r['content']}" for r in reversed(recent))
        # Web research is attempted for each question; actual Google search requires its official API credentials.
        search_results, search_error, provider_answers = research_question(message)
        if not provider_answers:
            answer = ("No AI provider is configured. Add GEMINI_API_KEY, OPENAI_API_KEY, "
                      "ANTHROPIC_API_KEY, or PERPLEXITY_API_KEY to .env, then restart JARVIS.")
            save_message("assistant", answer)
            return jsonify({"reply": answer, "configured": False, "sources": search_results, "providers": []})
        combined = "\n\n".join(f"--- {name} response ---\n{text}" for name, text in provider_answers.items()
                               if not text.startswith("(Provider unavailable:"))
        if not combined:
            answer = "All configured AI providers were unavailable. Check API keys, quota, and internet access."
        else:
            synthesis_prompt = (
                f"{SYSTEM_PROMPT}\nCombine these independent AI answers into one accurate, useful response. "
                "Resolve contradictions carefully, state uncertainty, and do not claim consensus if answers differ. "
                "If web sources are supplied, cite their URLs. Keep the final answer readable.\n"
                f"User-saved memory notes:\n{memory_context or '(none)'}\n"
                f"Recent conversation:\n{history_text}\nQuestion: {message}\n\n"
                f"Google results:\n{sources if 'sources' in locals() and sources else '(none)'}\n\n"
                f"Independent answers:\n{combined}"
            )
            # Use Gemini as synthesizer when available; otherwise use first successful provider response.
            try:
                if client:
                    response = client.models.generate_content(model=MODEL_NAME, contents=synthesis_prompt)
                    answer = (getattr(response, "text", None) or "").strip() or next(iter(provider_answers.values()))
                else:
                    answer = next((v for v in provider_answers.values() if not v.startswith("(Provider unavailable:")),
                                   "I could not get a response from the configured providers.")
            except Exception:
                answer = next((v for v in provider_answers.values() if not v.startswith("(Provider unavailable:")),
                              "I could not get a response from the configured providers.")
        if search_error and not search_results:
            answer += "\n\n_Web search note: Google Search is not connected. Configure GOOGLE_SEARCH_API_KEY and GOOGLE_SEARCH_CX to enable live Google results._"
        if search_results:
            answer += "\n\nSources:\n" + "\n".join(f"- {x['title']}: {x['url']}" for x in search_results)
    except Exception as exc:
        answer = f"Research request failed. Check your network and provider configuration. Details: {str(exc)[:220]}"
        search_results, provider_answers = [], {}
    save_message("assistant", answer)
    return jsonify({"reply": answer, "configured": bool(provider_answers), "sources": search_results,
                    "providers": list(provider_answers.keys()), "web_searched": bool(search_results)})

@app.post("/api/model")
def make_model():
    data = request.get_json(silent=True) or {}
    prompt = str(data.get("prompt", "")).strip()
    if not prompt:
        return jsonify({"error": "Describe the object you want to create."}), 400
    if len(prompt) > 1200:
        return jsonify({"error": "Model prompt must be under 1,200 characters."}), 400
    if not client:
        return jsonify({"error": "Gemini is not configured. Add GEMINI_API_KEY to .env and restart."}), 400
    instruction = """Write a valid, beginner-friendly OpenSCAD (.scad) script for a harmless decorative or functional object based on the request.
Use only standard OpenSCAD primitives and safe geometry. Do not create weapons, weapon parts, or harmful devices.
Return ONLY code, no markdown fences. Include comments and use millimetres. Keep complexity modest."""
    try:
        result = client.models.generate_content(model=MODEL_NAME, contents=instruction + "\nRequest: " + prompt)
        code = (getattr(result, "text", None) or "").strip()
        code = re.sub(r"^```(?:openscad|scad)?\s*", "", code, flags=re.I)
        code = re.sub(r"\s*```$", "", code)
        if not code or "module" not in code.lower() and "cube" not in code.lower() and "sphere" not in code.lower() and "cylinder" not in code.lower():
            return jsonify({"error": "The model generator did not return valid-looking OpenSCAD. Try a simpler description."}), 502
        filename = safe_filename(prompt[:36]) + ".scad"
        path = MODEL_DIR / filename
        path.write_text(code, encoding="utf-8")
        return jsonify({"ok": True, "filename": filename, "code": code, "download": f"/models/{filename}"})
    except Exception as exc:
        return jsonify({"error": f"Model generation failed: {str(exc)[:220]}"}), 500

@app.get("/models/<path:filename>")
def download_model(filename):
    return send_from_directory(MODEL_DIR, filename, as_attachment=True)


# Discover launchable applications from standard OS application locations.
# Only discovered application entries can be launched; no shell commands are accepted.
def discover_installed_apps():
    found = {}
    def add(name, kind, target):
        clean = str(name).strip()
        if clean and len(clean) < 120:
            key = re.sub(r"\s+", " ", clean).casefold()
            found.setdefault(key, {"id": key, "name": clean, "kind": kind, "target": str(target)})

    system = platform.system()
    if system == "Windows":
        roots = [
            Path(os.environ.get("APPDATA", "")) / "Microsoft/Windows/Start Menu/Programs",
            Path(os.environ.get("PROGRAMDATA", "")) / "Microsoft/Windows/Start Menu/Programs",
        ]
        for base in roots:
            if not base.is_dir():
                continue
            for item in list(base.rglob("*.lnk"))[:1500]:
                if item.is_file():
                    add(item.stem, "shortcut", item)
    elif system == "Darwin":
        for base in [Path("/Applications"), Path.home() / "Applications"]:
            if base.is_dir():
                for item in list(base.glob("*.app"))[:1000]:
                    add(item.stem, "mac_app", item)
    else:
        roots = [Path("/usr/share/applications"), Path("/usr/local/share/applications"),
                 Path.home() / ".local/share/applications"]
        for base in roots:
            if not base.is_dir():
                continue
            for item in list(base.glob("*.desktop"))[:1500]:
                try:
                    content = item.read_text(encoding="utf-8", errors="replace")
                    if "NoDisplay=true" in content or "Hidden=true" in content:
                        continue
                    name = next((line.split("=",1)[1].strip() for line in content.splitlines()
                                 if line.startswith("Name=")), item.stem)
                    # Store the desktop entry itself; launch through the desktop handler.
                    add(name, "desktop_entry", item)
                except OSError:
                    continue
    return found

def launch_discovered_app(app_id):
    apps = discover_installed_apps()
    entry = apps.get(str(app_id or "").casefold())
    if not entry:
        raise ValueError("App not found in the operating system's discoverable application list.")
    target = Path(entry["target"])
    if not target.exists():
        raise ValueError("This application shortcut no longer exists.")
    system = platform.system()
    if system == "Windows":
        os.startfile(str(target))
    elif system == "Darwin":
        subprocess.Popen(["open", str(target)], shell=False)
    else:
        # Open the .desktop file using the desktop environment, not a shell.
        subprocess.Popen(["gio", "launch", str(target)], shell=False)
    return entry["name"]

@app.get("/api/apps")
def list_installed_apps():
    apps = discover_installed_apps()
    return jsonify({"platform": platform.system(),
                    "apps": [{"id": a["id"], "name": a["name"], "kind": a["kind"]}
                             for a in sorted(apps.values(), key=lambda x: x["name"].casefold())[:1000]],
                    "count": len(apps),
                    "note": "Shows applications discoverable from standard OS app menus; some portable or store apps may not appear."})

@app.post("/api/apps/launch")
def launch_app():
    data = request.get_json(silent=True) or {}
    app_id = str(data.get("id", "")).strip()
    if data.get("confirm") is not True:
        return jsonify({"error": "Confirm before launching this application."}), 403
    try:
        name = launch_discovered_app(app_id)
        return jsonify({"ok": True, "message": f"Launch requested for {name}."})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 404
    except Exception as exc:
        return jsonify({"error": f"Could not launch app: {str(exc)[:180]}"}), 500


ALLOWED_SITES = {
    "google": "https://www.google.com", "youtube": "https://www.youtube.com",
    "wikipedia": "https://www.wikipedia.org", "github": "https://github.com",
    "gmail": "https://mail.google.com", "chatgpt": "https://chatgpt.com"
}
@app.post("/api/action")
def action():
    data = request.get_json(silent=True) or {}
    action_name = data.get("action")
    target = str(data.get("target", "")).strip().lower()
    if action_name == "open_site":
        url = ALLOWED_SITES.get(target)
        if not url:
            return jsonify({"error": "For safety, choose a supported site: Google, YouTube, Wikipedia, GitHub, Gmail, or ChatGPT."}), 400
        webbrowser.open(url)
        return jsonify({"ok": True, "message": f"Requested your default browser to open {target.title()}."})
    if action_name == "open_app":
        apps = {
            "windows": {"calculator": ["calc"], "notepad": ["notepad"], "paint": ["mspaint"]},
            "darwin": {"calculator": ["open", "-a", "Calculator"], "textedit": ["open", "-a", "TextEdit"]},
            "linux": {"calculator": ["gnome-calculator"], "text editor": ["gedit"]}
        }
        osname = platform.system().lower()
        family = "windows" if osname == "windows" else "darwin" if osname == "darwin" else "linux"
        cmd = apps.get(family, {}).get(target)
        if not cmd:
            return jsonify({"error": "App not in the approved list for this operating system. Try Calculator, Notepad, or Paint on Windows."}), 400
        try:
            subprocess.Popen(cmd, shell=False)
            return jsonify({"ok": True, "message": f"Requested launch of {target.title()}."})
        except Exception as exc:
            return jsonify({"error": f"Couldn't launch {target}: {str(exc)[:160]}"}), 500
    return jsonify({"error": "Unknown action."}), 400



def workspace_path(relative):
    """Resolve a user-provided path only inside the configured JARVIS workspace."""
    relative = str(relative or "").strip().replace("\\", "/")
    if not relative or relative.startswith("/") or re.match(r"^[A-Za-z]:", relative):
        raise ValueError("Choose a relative path inside the JARVIS workspace.")
    candidate = (WORKSPACE / relative).resolve()
    if candidate != WORKSPACE and WORKSPACE not in candidate.parents:
        raise ValueError("That path is outside the JARVIS workspace.")
    return candidate

@app.get("/api/files")
def list_files():
    rel = request.args.get("path", "")
    try:
        folder = workspace_path(rel) if rel else WORKSPACE
        if not folder.exists() or not folder.is_dir():
            return jsonify({"error": "Folder not found."}), 404
        items = []
        for p in sorted(folder.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))[:300]:
            if p.is_symlink():
                continue
            items.append({"name": p.name, "path": p.relative_to(WORKSPACE).as_posix(),
                          "type": "folder" if p.is_dir() else "file",
                          "size": p.stat().st_size if p.is_file() else None})
        return jsonify({"workspace": str(WORKSPACE), "path": rel, "items": items})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

@app.get("/api/files/read")
def read_file():
    try:
        p = workspace_path(request.args.get("path", ""))
        if p.is_symlink() or not p.is_file():
            return jsonify({"error": "File not found."}), 404
        if p.suffix.lower() not in ALLOWED_EXTENSIONS:
            return jsonify({"error": "For safety, preview is limited to common text/code file types."}), 400
        if p.stat().st_size > MAX_FILE_BYTES:
            return jsonify({"error": "File is too large to preview (200 KB limit)."}), 413
        return jsonify({"path": p.relative_to(WORKSPACE).as_posix(), "content": p.read_text(encoding="utf-8", errors="replace")})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

@app.post("/api/files/write")
def write_file():
    data = request.get_json(silent=True) or {}
    try:
        p = workspace_path(data.get("path", ""))
        content = str(data.get("content", ""))
        if data.get("confirm") is not True:
            return jsonify({"error": "Confirmation is required before saving a file."}), 403
        if p.suffix.lower() not in ALLOWED_EXTENSIONS:
            return jsonify({"error": "Allowed file types: " + ", ".join(sorted(ALLOWED_EXTENSIONS))}), 400
        if len(content.encode("utf-8")) > MAX_FILE_BYTES:
            return jsonify({"error": "File exceeds the 200 KB limit."}), 413
        p.parent.mkdir(parents=True, exist_ok=True)
        if p.exists() and p.is_dir():
            return jsonify({"error": "That path is a folder."}), 400
        p.write_text(content, encoding="utf-8")
        return jsonify({"ok": True, "message": f"Saved {p.relative_to(WORKSPACE).as_posix()}"})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

@app.post("/api/files/delete")
def delete_file():
    data = request.get_json(silent=True) or {}
    try:
        p = workspace_path(data.get("path", ""))
        if data.get("confirm") is not True:
            return jsonify({"error": "Confirmation is required before deleting."}), 403
        if p == WORKSPACE or p.is_symlink() or not p.exists():
            return jsonify({"error": "That item cannot be deleted or was not found."}), 400
        if p.is_dir():
            return jsonify({"error": "Folder deletion is disabled. Delete files individually."}), 400
        p.unlink()
        return jsonify({"ok": True, "message": "File deleted."})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

@app.get("/api/system")
def system_info():
    usage = shutil.disk_usage(WORKSPACE)
    result = {
        "platform": platform.platform(),
        "python": platform.python_version(),
        "cpu_count": os.cpu_count() or 0,
        "disk_total_gb": round(usage.total / (1024**3), 2),
        "disk_free_gb": round(usage.free / (1024**3), 2),
        "workspace": str(WORKSPACE),
    }
    try:
        import psutil
        result["ram_percent"] = psutil.virtual_memory().percent
        result["cpu_percent"] = psutil.cpu_percent(interval=0.15)
        result["battery_percent"] = psutil.sensors_battery().percent if psutil.sensors_battery() else None
    except Exception:
        result["ram_percent"] = None
        result["cpu_percent"] = None
        result["battery_percent"] = None
    return jsonify(result)

@app.get("/api/status")
def status():
    return jsonify({
         "configured": bool(client or OPENAI_API_KEY or ANTHROPIC_API_KEY or PERPLEXITY_API_KEY),
        "model": MODEL_NAME,
        "providers": {"Gemini": bool(client), "OpenAI": bool(OPENAI_API_KEY),
                      "Anthropic Claude": bool(ANTHROPIC_API_KEY), "Perplexity": bool(PERPLEXITY_API_KEY)},
        "google_search_configured": bool(GOOGLE_SEARCH_KEY and GOOGLE_SEARCH_CX),
        "platform": platform.system(),
        "python": platform.python_version(),
        "memory_db": DB_PATH.exists(),
        "models_count": len(list(MODEL_DIR.glob("*.scad")))
    })

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)
