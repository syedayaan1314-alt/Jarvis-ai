#!/usr/bin/env python3
"""JARVIS device pairing and approval service. Keep behind HTTPS/VPN; do not port-forward publicly."""
import os, sqlite3, secrets, hashlib, hmac, json, time, threading
from pathlib import Path
from datetime import datetime, timezone
from flask import Flask, request, jsonify, render_template
from dotenv import load_dotenv
BASE=Path(__file__).resolve().parent
load_dotenv(BASE/'.env')
DB=BASE/'devices.sqlite3'
APP=Flask(__name__, template_folder=str(BASE/'multi_device'/'templates'), static_folder=str(BASE/'multi_device'/'static'))
ADMIN_TOKEN=os.getenv('JARVIS_ADMIN_TOKEN','')
PAIR_CODE=os.getenv('JARVIS_PAIR_CODE','')
LOCK=threading.Lock()

def conn():
 c=sqlite3.connect(DB, timeout=10); c.row_factory=sqlite3.Row
 c.executescript("""CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY,name TEXT NOT NULL,platform TEXT NOT NULL,token_hash TEXT NOT NULL,last_seen TEXT,created_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS pair_codes(code_hash TEXT PRIMARY KEY,expires REAL NOT NULL,used INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS actions(id INTEGER PRIMARY KEY AUTOINCREMENT,device_id TEXT NOT NULL,action TEXT NOT NULL,args TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,approved_at TEXT,result TEXT);
 CREATE TABLE IF NOT EXISTS shared_messages(id INTEGER PRIMARY KEY AUTOINCREMENT,device_id TEXT,role TEXT NOT NULL,content TEXT NOT NULL,created_at TEXT NOT NULL);""")
 return c

def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def digest(s): return hashlib.sha256(s.encode()).hexdigest()
def admin_ok():
 # Admin bearer token must be set by operator; fail closed if missing.
 return bool(ADMIN_TOKEN) and hmac.compare_digest(request.headers.get('Authorization','').removeprefix('Bearer ').strip(),ADMIN_TOKEN)
def device_auth():
 did=request.headers.get('X-Jarvis-Device',''); token=request.headers.get('X-Jarvis-Token','')
 if not did or not token: return None
 with conn() as c:
  row=c.execute('SELECT * FROM devices WHERE id=?',(did,)).fetchone()
 if not row or not hmac.compare_digest(row['token_hash'],digest(token)): return None
 with conn() as c: c.execute('UPDATE devices SET last_seen=? WHERE id=?',(now(),did))
 return row

@APP.get('/')
def home(): return render_template('devices.html')
@APP.get('/health')
def health(): return jsonify({'ok':True,'service':'JARVIS device pairing','time':now()})

@APP.post('/api/admin/pair-code')
def create_pair_code():
 if not admin_ok(): return jsonify(error='Admin authentication required; set JARVIS_ADMIN_TOKEN and send it as a Bearer token.'),401
 code=secrets.token_urlsafe(7)
 with conn() as c: c.execute('INSERT INTO pair_codes(code_hash,expires,used) VALUES(?,?,0)',(digest(code),time.time()+300))
 return jsonify(code=code,expires_in_seconds=300,note='Share this code only with the device you intend to pair.')

@APP.post('/api/pair')
def pair():
 d=request.get_json(silent=True) or {}; code=str(d.get('code','')); name=str(d.get('name','Device'))[:80]; plat=str(d.get('platform','unknown'))[:40]
 if not code: return jsonify(error='Pair code required.'),400
 with conn() as c:
  row=c.execute('SELECT * FROM pair_codes WHERE code_hash=? AND used=0',(digest(code),)).fetchone()
  if not row or row['expires']<time.time(): return jsonify(error='Pair code is invalid, expired, or already used.'),403
  c.execute('UPDATE pair_codes SET used=1 WHERE code_hash=?',(digest(code),))
 did=secrets.token_hex(12); token=secrets.token_urlsafe(32)
 with conn() as c: c.execute('INSERT INTO devices(id,name,platform,token_hash,last_seen,created_at) VALUES(?,?,?,?,?,?)',(did,name,plat,digest(token),now(),now()))
 return jsonify(device_id=did,device_token=token,warning='Save this token securely. It is shown only once; never share it.'),201

@APP.get('/api/admin/devices')
def list_devices():
 if not admin_ok(): return jsonify(error='Admin authentication required.'),401
 with conn() as c: rows=c.execute('SELECT id,name,platform,last_seen,created_at FROM devices ORDER BY created_at DESC').fetchall()
 return jsonify(devices=[dict(x) for x in rows])

@APP.post('/api/admin/actions')
def queue_action():
 if not admin_ok(): return jsonify(error='Admin authentication required.'),401
 d=request.get_json(silent=True) or {}; did=str(d.get('device_id','')); action=str(d.get('action',''))
 # Small allowlist. No arbitrary shell commands, scripts, keystroke injection, or file exfiltration.
 allowed={'open_url','get_system_info','notify'}
 if action not in allowed: return jsonify(error='Action is not on the allowlist.'),400
 with conn() as c:
  if not c.execute('SELECT 1 FROM devices WHERE id=?',(did,)).fetchone(): return jsonify(error='Unknown device.'),404
  cur=c.execute('INSERT INTO actions(device_id,action,args,status,created_at) VALUES(?,?,? ,\'pending_approval\',?)',(did,action,json.dumps(d.get('args',{})),now()))
 return jsonify(action_id=cur.lastrowid,status='pending_approval',message='The user must explicitly approve this action in the dashboard before it can run.'),201

@APP.post('/api/admin/actions/<int:aid>/approve')
def approve(aid):
 if not admin_ok(): return jsonify(error='Admin authentication required.'),401
 with conn() as c:
  cur=c.execute("UPDATE actions SET status='approved',approved_at=? WHERE id=? AND status='pending_approval'",(now(),aid))
  if cur.rowcount==0: return jsonify(error='Action not found or not awaiting approval.'),404
 return jsonify(ok=True,status='approved')
@APP.post('/api/admin/actions/<int:aid>/reject')
def reject(aid):
 if not admin_ok(): return jsonify(error='Admin authentication required.'),401
 with conn() as c:
  cur=c.execute("UPDATE actions SET status='rejected' WHERE id=? AND status='pending_approval'",(aid,))
  if cur.rowcount==0: return jsonify(error='Action not found or not awaiting approval.'),404
 return jsonify(ok=True,status='rejected')

@APP.get('/api/admin/actions')
def list_actions():
 if not admin_ok(): return jsonify(error='Admin authentication required.'),401
 with conn() as c: rows=c.execute('SELECT a.*,d.name device_name FROM actions a LEFT JOIN devices d ON d.id=a.device_id ORDER BY a.id DESC LIMIT 100').fetchall()
 return jsonify(actions=[dict(x) for x in rows])

@APP.get('/api/device/tasks')
def device_tasks():
 dev=device_auth()
 if not dev: return jsonify(error='Device authentication failed.'),401
 with conn() as c:
  rows=c.execute("SELECT * FROM actions WHERE device_id=? AND status='approved' ORDER BY id ASC LIMIT 10",(dev['id'],)).fetchall()
  for r in rows: c.execute("UPDATE actions SET status='delivered' WHERE id=? AND status='approved'",(r['id'],))
 return jsonify(tasks=[{'id':r['id'],'action':r['action'],'args':json.loads(r['args'])} for r in rows])

@APP.post('/api/device/result')
def device_result():
 dev=device_auth()
 if not dev: return jsonify(error='Device authentication failed.'),401
 d=request.get_json(silent=True) or {}; aid=int(d.get('action_id',0)); result=str(d.get('result',''))[:3000]
 with conn() as c:
  cur=c.execute("UPDATE actions SET status='completed',result=? WHERE id=? AND device_id=? AND status='delivered'",(result,aid,dev['id']))
  if cur.rowcount==0: return jsonify(error='Unknown action or invalid status.'),404
 return jsonify(ok=True)

@APP.get('/api/device/status')
def device_status():
 dev=device_auth()
 if not dev: return jsonify(error='Device authentication failed.'),401
 return jsonify(device={'id':dev['id'],'name':dev['name'],'platform':dev['platform'],'last_seen':dev['last_seen']})

@APP.get('/api/shared/messages')
def shared_messages():
 dev=device_auth()
 if not dev: return jsonify(error='Device authentication failed.'),401
 with conn() as c: rows=c.execute('SELECT role,content,created_at FROM shared_messages ORDER BY id DESC LIMIT 50').fetchall()
 return jsonify(messages=[dict(x) for x in reversed(rows)])
@APP.post('/api/shared/messages')
def add_shared_message():
 dev=device_auth(); d=request.get_json(silent=True) or {}; content=str(d.get('content','')).strip()
 if not dev: return jsonify(error='Device authentication failed.'),401
 if not content or len(content)>4000: return jsonify(error='Message must be 1–4000 characters.'),400
 with conn() as c: c.execute('INSERT INTO shared_messages(device_id,role,content,created_at) VALUES(?,?,?,?)',(dev['id'],'user',content,now()))
 return jsonify(ok=True)

if __name__=='__main__':
 if not ADMIN_TOKEN:
  print('WARNING: set JARVIS_ADMIN_TOKEN in .env before using admin endpoints.')
 host=os.getenv('JARVIS_BIND_HOST','127.0.0.1'); port=int(os.getenv('JARVIS_DEVICE_PORT','5055'))
 print(f'JARVIS device service listening on {host}:{port}. Use HTTPS or a private VPN before connecting other devices.')
 APP.run(host=host,port=port,debug=False)
