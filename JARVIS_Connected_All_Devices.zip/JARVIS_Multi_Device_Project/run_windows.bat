@echo off
cd /d "%~dp0"
if not exist .venv (
  py -3 -m venv .venv 2>nul
  if errorlevel 1 python -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo If this is your first run, edit .env and add your Gemini API key.
echo Starting JARVIS at http://127.0.0.1:5000
start "" http://127.0.0.1:5000
python app.py
pause
