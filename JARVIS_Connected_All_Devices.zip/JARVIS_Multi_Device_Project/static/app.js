const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let wakeRecognition = null, micRecognition = null, wakeActive = false;
const toast = (msg) => { const el=$("#toast"); el.textContent=msg; el.classList.add("show"); clearTimeout(window.__toastTimer); window.__toastTimer=setTimeout(()=>el.classList.remove("show"),3200); };
function switchView(name){ $$(".view").forEach(v=>v.classList.toggle("active",v.id===`view-${name}`)); $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===name)); if(name==="productivity") loadMemories(); if(name==="chat") $("#chat-input").focus(); }
$$("[data-view]").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));
$$("[data-goto]").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.goto)));
function updateClock(){const d=new Date();$("#clock").textContent=d.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});}
updateClock();setInterval(updateClock,10000);
async function api(url, options={}){const r=await fetch(url,{headers:{"Content-Type":"application/json"},...options});const data=await r.json();if(!r.ok)throw new Error(data.error||"Request failed");return data;}
async function loadStatus(){try{const s=await api("/api/status");$("#api-status").textContent=s.configured?"CONNECTED":"API KEY NEEDED";$("#api-meter").style.width=s.configured?"100%":"15%";$("#model-status").textContent=s.configured?`Gemini · ${s.model}`:"Add Gemini API key";$("#setting-model").textContent=s.model;$("#setting-platform").textContent=s.platform;$("#models-count").textContent=s.models_count;$("#models-meter").style.width=Math.min(100,10+s.models_count*10)+"%";$("#memory-status").textContent="LOCAL DB";}catch(e){toast(e.message)}}
function addMessage(role,text){const feed=$("#chat-feed");const empty=feed.querySelector(".welcome-message");if(empty)empty.remove();const wrap=document.createElement("div");wrap.className="message "+(role==="user"?"user":"assistant");const bubble=document.createElement("div");bubble.className="bubble";const who=document.createElement("span");who.className="who";who.textContent=role==="user"?"YOU":"JARVIS";bubble.append(who,document.createTextNode(text));if(role!=="user"){const avatar=document.createElement("div");avatar.className="bot-avatar";avatar.textContent="J";wrap.append(avatar,bubble)}else wrap.append(bubble);feed.append(wrap);feed.scrollTop=feed.scrollHeight;}
async function loadHistory(){try{const d=await api("/api/history");if(d.messages.length){$("#chat-feed").innerHTML="";d.messages.forEach(m=>addMessage(m.role,m.content));}}catch(e){}}
async function sendChat(text){text=(text??$("#chat-input").value).trim();if(!text)return;$("#chat-input").value="";addMessage("user",text);const btn=$("#send-btn");btn.disabled=true;$("#voice-state").textContent="JARVIS IS THINKING…";try{const d=await api("/api/chat",{method:"POST",body:JSON.stringify({message:text})});addMessage("assistant",d.reply);if($("#speak-toggle").checked) speak(d.reply);if(!d.configured)toast("Add your Gemini key in .env to enable AI replies.");}catch(e){addMessage("assistant",e.message);toast(e.message)}finally{btn.disabled=false;$("#voice-state").textContent="VOICE INPUT READY";}}
$("#send-btn").addEventListener("click",()=>sendChat());
$("#chat-input").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendChat();}});
$("#clear-chat").addEventListener("click",async()=>{if(!confirm("Clear all saved conversation history?"))return;try{await api("/api/history",{method:"DELETE"});$("#chat-feed").innerHTML='<div class="welcome-message"><div class="bot-avatar">J</div><div><b>JARVIS</b><p>History cleared, Sir. Ready when you are.</p></div></div>';toast("Chat history cleared.");}catch(e){toast(e.message)}});
$("#clear-all").addEventListener("click",()=>$("#clear-chat").click());
function speak(text){if(!("speechSynthesis"in window))return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.rate=1.02;u.pitch=.9;window.speechSynthesis.speak(u);}
function makeRecognition(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){toast("Speech recognition is not supported in this browser. Try Chrome or Edge.");return null;}const r=new SR();r.lang="en-US";r.interimResults=false;r.continuous=false;return r;}
$("#mic-btn").addEventListener("click",()=>{if(micRecognition){micRecognition.stop();micRecognition=null;$("#mic-btn").classList.remove("listening");return;}micRecognition=makeRecognition();if(!micRecognition)return;micRecognition.onstart=()=>{$("#mic-btn").classList.add("listening");$("#voice-state").textContent="LISTENING…";};micRecognition.onresult=e=>{const words=e.results[0][0].transcript;$("#chat-input").value=words;sendChat(words);};micRecognition.onerror=e=>toast("Microphone: "+e.error);micRecognition.onend=()=>{$("#mic-btn").classList.remove("listening");$("#voice-state").textContent="VOICE INPUT READY";micRecognition=null;};try{micRecognition.start()}catch(e){toast("Could not start microphone.")}});
$("#quick-voice").addEventListener("click",()=>{switchView("chat");$("#mic-btn").click();});
async function doAction(action,target){try{const d=await api("/api/action",{method:"POST",body:JSON.stringify({action,target})});toast(d.message||"Done.");}catch(e){toast(e.message)}}
$$("[data-action]").forEach(b=>b.addEventListener("click",()=>doAction(b.dataset.action,b.dataset.target)));
$("#generate-model").addEventListener("click",async()=>{const prompt=$("#model-prompt").value.trim();if(!prompt){toast("Describe the object first.");return;}const btn=$("#generate-model"),out=$("#model-result");btn.disabled=true;btn.textContent="Generating…";out.textContent="JARVIS is drafting your OpenSCAD model…";try{const d=await api("/api/model",{method:"POST",body:JSON.stringify({prompt})});out.textContent=d.code+"\n\n";const a=document.createElement("a");a.className="download-link";a.href=d.download;a.textContent="↓ Download "+d.filename;a.download=d.filename;out.append(a);toast("3D model script generated.");loadStatus();}catch(e){out.textContent=e.message;toast(e.message)}finally{btn.disabled=false;btn.textContent="✦ Generate 3D Model";}});
async function loadMemories(){try{const d=await api("/api/memories");const list=$("#memory-list");list.innerHTML="";if(!d.memories.length){list.textContent="No saved notes yet.";return;}d.memories.forEach(m=>{const row=document.createElement("div");row.className="memory-item";const span=document.createElement("span");span.textContent=m.note;const del=document.createElement("button");del.textContent="Delete";del.addEventListener("click",async()=>{try{await api("/api/memories/"+m.id,{method:"DELETE"});loadMemories();toast("Note deleted.");}catch(e){toast(e.message)}});row.append(span,del);list.append(row);});}catch(e){toast(e.message)}}
$("#save-memory").addEventListener("click",async()=>{const note=$("#memory-input").value.trim();if(!note)return toast("Enter a note first.");try{await api("/api/memories",{method:"POST",body:JSON.stringify({note})});$("#memory-input").value="";await loadMemories();toast("Memory note saved.");}catch(e){toast(e.message)}});
function stopWake(){wakeActive=false;if(wakeRecognition){wakeRecognition.onend=null;wakeRecognition.stop();wakeRecognition=null;}$("#wake-status").textContent="Wake word is off.";}
function startWake(){wakeRecognition=makeRecognition();if(!wakeRecognition){$("#wake-toggle").checked=false;return;}wakeActive=true;$("#wake-status").textContent='Listening for “Hey Jarvis”… keep this tab open.';wakeRecognition.continuous=true;wakeRecognition.interimResults=true;wakeRecognition.onresult=e=>{for(let i=e.resultIndex;i<e.results.length;i++){if(!e.results[i].isFinal)continue;const phrase=e.results[i][0].transcript.toLowerCase();if(phrase.includes("hey jarvis")||phrase.includes("hey, jarvis")){const command=phrase.replace(/hey,?\s*jarvis[,]?/,"").trim();switchView("chat");if(command)sendChat(command);else speak("I'm listening, Sir.");}}};wakeRecognition.onerror=e=>{$("#wake-status").textContent="Voice recognition stopped: "+e.error;};wakeRecognition.onend=()=>{if(wakeActive){try{wakeRecognition.start()}catch(e){}}};try{wakeRecognition.start()}catch(e){toast("Could not enable wake word.");$("#wake-toggle").checked=false;stopWake();}}
$("#wake-toggle").addEventListener("change",e=>{if(e.target.checked)startWake();else stopWake();});
loadStatus();loadHistory();loadMemories();


// Restricted workspace file manager: all paths are validated server-side.
async function loadFiles(){
  try{
    const d=await api("/api/files");
    $("#workspace-path").textContent=d.workspace;
    const list=$("#file-list");list.innerHTML="";
    if(!d.items.length){list.textContent="Workspace is empty.";return;}
    d.items.forEach(item=>{
      const row=document.createElement("div");row.className="file-row";
      const name=document.createElement("button");name.className="file-name";name.textContent=(item.type==="folder"?"▰ ":"▤ ")+item.name;
      const meta=document.createElement("small");meta.textContent=item.type==="folder"?"FOLDER":`${Math.ceil((item.size||0)/1024)} KB`;
      name.addEventListener("click",async()=>{
        if(item.type==="folder"){toast("Folder navigation is limited to the workspace root in this version.");return;}
        $("#file-path").value=item.path;
        try{const f=await api("/api/files/read?path="+encodeURIComponent(item.path));$("#file-content").value=f.content;}
        catch(e){$("#file-content").value="";toast(e.message);}
      });
      row.append(name,meta);list.append(row);
    });
  }catch(e){toast(e.message);}
}
$("#refresh-files")?.addEventListener("click",loadFiles);
$("#new-file")?.addEventListener("click",async()=>{
  const path=$("#file-path").value.trim();if(!path)return toast("Enter a relative filename first.");
  try{const f=await api("/api/files/read?path="+encodeURIComponent(path));$("#file-content").value=f.content;toast("File loaded.");}
  catch(e){if(confirm("File could not be loaded. Create it as a new file?")){$("#file-content").value="";}}
});
$("#save-file")?.addEventListener("click",async()=>{
  const path=$("#file-path").value.trim(),content=$("#file-content").value;
  if(!path)return toast("Enter a relative filename.");
  if(!confirm(`Save "${path}" inside the JARVIS workspace?`))return;
  try{const d=await api("/api/files/write",{method:"POST",body:JSON.stringify({path,content,confirm:true})});toast(d.message);loadFiles();}
  catch(e){toast(e.message);}
});
$("#delete-file")?.addEventListener("click",async()=>{
  const path=$("#file-path").value.trim();if(!path)return toast("Select a file first.");
  if(!confirm(`Permanently delete "${path}"? This cannot be undone.`))return;
  try{const d=await api("/api/files/delete",{method:"POST",body:JSON.stringify({path,confirm:true})});$("#file-path").value="";$("#file-content").value="";toast(d.message);loadFiles();}
  catch(e){toast(e.message);}
});
async function loadSystemInfo(){
 try{const s=await api("/api/system");$("#sys-cores").textContent=s.cpu_count;$("#sys-cpu").textContent=s.cpu_percent==null?"Unavailable":s.cpu_percent+"%";$("#sys-ram").textContent=s.ram_percent==null?"Unavailable":s.ram_percent+"%";$("#sys-disk").textContent=s.disk_free_gb+" GB";$("#sys-platform").textContent=s.platform+" · Python "+s.python;}
 catch(e){}
}
const originalSwitchView=switchView;
switchView=function(name){originalSwitchView(name);if(name==="files")loadFiles();if(name==="control")loadSystemInfo();};


// App launcher catalog: server exposes only discovered OS app-menu entries.
let discoveredApps = [];
async function loadInstalledApps(){
  const list=$("#installed-app-list");
  if(!list)return;
  list.textContent="Scanning apps…";
  try{
    const data=await api("/api/apps");
    discoveredApps=data.apps||[];
    $("#app-count").textContent=`${discoveredApps.length} found · ${data.platform}`;
    renderInstalledApps();
  }catch(e){list.textContent=e.message;toast(e.message);}
}
function renderInstalledApps(){
  const list=$("#installed-app-list");if(!list)return;
  const q=($("#app-search")?.value||"").trim().toLowerCase();
  const matches=discoveredApps.filter(a=>a.name.toLowerCase().includes(q));
  list.innerHTML="";
  if(!matches.length){list.textContent="No matching apps found. Some portable/store apps may not be listed.";return;}
  matches.slice(0,250).forEach(a=>{
    const row=document.createElement("div");row.className="installed-app-row";
    const name=document.createElement("span");name.textContent="▣ "+a.name;
    const launch=document.createElement("button");launch.className="action-btn";launch.textContent="Launch";
    launch.addEventListener("click",async()=>{
      if(!confirm(`Allow JARVIS to launch "${a.name}"?`))return;
      try{const result=await api("/api/apps/launch",{method:"POST",body:JSON.stringify({id:a.id,confirm:true})});toast(result.message);}
      catch(e){toast(e.message);}
    });
    row.append(name,launch);list.append(row);
  });
}
$("#refresh-apps")?.addEventListener("click",loadInstalledApps);
$("#app-search")?.addEventListener("input",renderInstalledApps);
const priorSwitchView=switchView;
switchView=function(name){priorSwitchView(name);if(name==="control"){loadSystemInfo();loadInstalledApps();}};
